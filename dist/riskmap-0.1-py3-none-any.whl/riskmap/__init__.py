from pathlib import Path

ROOT_DIR = Path(__file__).parents[1]